
const name = "Sean";
const welcomeText = document.getElementById("welcome");

welcomeText.textContent = "Welcome, " + name + "!";



let count = 0;

const counter = document.getElementById("counter");
const addBtn = document.getElementById("addSession");
const resetBtn = document.getElementById("resetSession");

addBtn.onclick = function() {
count++;
counter.textContent = "Study sessions today: " + count;
};

resetBtn.onclick = function() {
count = 0;
counter.textContent = "Study sessions today: " + count;
};



const goals = [
"Read notes",
"Finish lab",
"Practice JavaScript"
];

for(let i = 0; i < goals.length; i++){
console.log(goals[i]);
}

const showGoalsBtn = document.getElementById("showGoals");
const goalList = document.getElementById("goalList");

showGoalsBtn.onclick = function(){

goalList.innerHTML = "";

for(let i = 0; i < goals.length; i++){

let li = document.createElement("li");
li.textContent = goals[i];

goalList.appendChild(li);

}

};



const hoursStudied = 3;

if(hoursStudied >= 3){
console.log("Good progress");
}
else{
console.log("You should study more");
}