const express = require("express");
const sqlite3 = require("sqlite3").verbose();
const path = require("path");

const app = express();
const PORT = 3000;
const DB_PATH = path.join(__dirname, "database.db");

app.use(express.json());

const db = new sqlite3.Database(DB_PATH, (err) => {
  if (err) {
    console.error("Failed to connect to database:", err.message);
    process.exit(1);
  }
  console.log("Connected to SQLite database.");
});

db.run(
  `CREATE TABLE IF NOT EXISTS books (
    id     INTEGER PRIMARY KEY AUTOINCREMENT,
    title  TEXT    NOT NULL,
    author TEXT    NOT NULL,
    year   INTEGER,
    status TEXT    NOT NULL CHECK(status IN ('to-read', 'reading', 'completed'))
  )`,
  (err) => {
    if (err) {
      console.error("Failed to create table:", err.message);
    } else {
      console.log("Books table ready.");
    }
  }
);


const VALID_STATUSES = ["to-read", "reading", "completed"];

function isValidStatus(status) {
  return VALID_STATUSES.includes(status);
}

app.get("/books", (req, res) => {
  const { status } = req.query;

  if (status !== undefined) {
    if (!isValidStatus(status)) {
      return res.status(400).json({
        error: `Invalid status. Allowed values: ${VALID_STATUSES.join(", ")}`,
      });
    }
    db.all("SELECT * FROM books WHERE status = ?", [status], (err, rows) => {
      if (err) return res.status(500).json({ error: err.message });
      res.json(rows);
    });
  } else {
    db.all("SELECT * FROM books", [], (err, rows) => {
      if (err) return res.status(500).json({ error: err.message });
      res.json(rows);
    });
  }
});

app.get("/books/:id", (req, res) => {
  const { id } = req.params;
  db.get("SELECT * FROM books WHERE id = ?", [id], (err, row) => {
    if (err) return res.status(500).json({ error: err.message });
    if (!row) return res.status(404).json({ error: "Book not found." });
    res.json(row);
  });
});

app.post("/books", (req, res) => {
  const { title, author, year, status } = req.body;

  if (!title || !author || !status) {
    return res
      .status(400)
      .json({ error: "title, author, and status are required." });
  }
  if (!isValidStatus(status)) {
    return res.status(400).json({
      error: `Invalid status. Allowed values: ${VALID_STATUSES.join(", ")}`,
    });
  }

  db.run(
    "INSERT INTO books (title, author, year, status) VALUES (?, ?, ?, ?)",
    [title, author, year ?? null, status],
    function (err) {
      if (err) return res.status(500).json({ error: err.message });
      res.status(201).json({ id: this.lastID });
    }
  );
});

app.put("/books/:id", (req, res) => {
  const { id } = req.params;
  const { title, year, status } = req.body;

  if (status !== undefined && !isValidStatus(status)) {
    return res.status(400).json({
      error: `Invalid status. Allowed values: ${VALID_STATUSES.join(", ")}`,
    });
  }

  const fields = [];
  const values = [];

  if (title !== undefined) { fields.push("title = ?");  values.push(title); }
  if (year  !== undefined) { fields.push("year = ?");   values.push(year);  }
  if (status !== undefined) { fields.push("status = ?"); values.push(status); }

  if (fields.length === 0) {
    return res
      .status(400)
      .json({ error: "Provide at least one field to update (title, year, status)." });
  }

  values.push(id); // for the WHERE clause

  db.run(
    `UPDATE books SET ${fields.join(", ")} WHERE id = ?`,
    values,
    function (err) {
      if (err) return res.status(500).json({ error: err.message });
      if (this.changes === 0)
        return res.status(404).json({ error: "Book not found." });
      res.json({ message: "Book updated successfully." });
    }
  );
});

app.delete("/books/:id", (req, res) => {
  const { id } = req.params;
  db.run("DELETE FROM books WHERE id = ?", [id], function (err) {
    if (err) return res.status(500).json({ error: err.message });
    if (this.changes === 0)
      return res.status(404).json({ error: "Book not found." });
    res.json({ message: "Book deleted successfully." });
  });
});


app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
