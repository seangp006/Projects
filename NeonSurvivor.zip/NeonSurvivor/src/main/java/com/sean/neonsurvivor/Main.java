package com.sean.neonsurvivor;

import javax.swing.JFrame;
import com.sean.neonsurvivor.game.GamePanel;

public class Main {
    public static void main(String[] args) {
        JFrame window = new JFrame("Neon Survivor");
        GamePanel game = new GamePanel();

        window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        window.setResizable(false);
        window.add(game);
        window.pack();
        window.setLocationRelativeTo(null);
        window.setVisible(true);

        game.start();
    }
}
