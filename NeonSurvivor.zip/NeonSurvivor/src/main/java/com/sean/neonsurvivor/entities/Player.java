package com.sean.neonsurvivor.entities;

import java.awt.Color;
import java.awt.Graphics2D;

public class Player extends Entity {
    private double speed = 4.0;
    private int health = 100;
    private int maxHealth = 100;
    private int damage = 25;
    private int shootDelay = 180;
    private int shootTimer = 0;

    private boolean up, down, left, right;

    public Player(double x, double y) {
        super(x, y, 28, 28);
    }

    @Override
    public void update() {
        if (up) y -= speed;
        if (down) y += speed;
        if (left) x -= speed;
        if (right) x += speed;
        if (shootTimer > 0) shootTimer--;
    }

    public void draw(Graphics2D g) {
        g.setColor(new Color(70, 220, 255));
        g.fillOval((int)x, (int)y, width, height);
        g.setColor(Color.WHITE);
        g.fillOval((int)x + 8, (int)y + 7, 5, 5);
        g.fillOval((int)x + 17, (int)y + 7, 5, 5);
    }

    public boolean canShoot() {
        return shootTimer <= 0;
    }

    public void resetShootTimer() {
        shootTimer = shootDelay;
    }

    public void damage(int amount) {
        health -= amount;
    }

    public void heal(int amount) {
        health = Math.min(maxHealth, health + amount);
    }

    public void setMovement(boolean up, boolean down, boolean left, boolean right) {
        this.up = up; this.down = down; this.left = left; this.right = right;
    }

    public int getHealth() { return health; }
    public int getMaxHealth() { return maxHealth; }
    public int getDamage() { return damage; }
    public double getSpeed() { return speed; }

    public void increaseDamage(int amount) { damage += amount; }
    public void increaseSpeed(double amount) { speed += amount; }
    public void increaseMaxHealth(int amount) { maxHealth += amount; health += amount; }
    public void reduceShootDelay(int amount) { shootDelay = Math.max(60, shootDelay - amount); }
}
