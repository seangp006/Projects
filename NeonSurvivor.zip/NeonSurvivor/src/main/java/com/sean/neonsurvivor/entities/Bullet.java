package com.sean.neonsurvivor.entities;

import java.awt.Color;
import java.awt.Graphics2D;

public class Bullet extends Entity {
    private final double dx;
    private final double dy;
    private final int damage;

    public Bullet(double x, double y, double targetX, double targetY, int damage) {
        super(x, y, 7, 7);
        double length = Math.sqrt(targetX * targetX + targetY * targetY);
        dx = targetX / length * 9;
        dy = targetY / length * 9;
        this.damage = damage;
    }

    @Override
    public void update() {
        x += dx;
        y += dy;
    }

    @Override
    public void draw(Graphics2D g) {
        g.setColor(Color.YELLOW);
        g.fillOval((int)x, (int)y, width, height);
    }

    public int getDamage() { return damage; }
}
