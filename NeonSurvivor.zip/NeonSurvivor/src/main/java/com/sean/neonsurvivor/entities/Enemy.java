package com.sean.neonsurvivor.entities;

import java.awt.Color;
import java.awt.Graphics2D;

public class Enemy extends Entity {
    public enum Type { BASIC, FAST, TANK }

    private final Type type;
    private final Player player;
    private int health;
    private final double speed;
    private final Color color;

    public Enemy(double x, double y, Type type, Player player, int wave) {
        super(x, y, type == Type.TANK ? 34 : 24, type == Type.TANK ? 34 : 24);
        this.type = type;
        this.player = player;

        if (type == Type.FAST) {
            health = 30 + wave * 2;
            speed = 2.4 + wave * 0.03;
            color = new Color(255, 210, 70);
        } else if (type == Type.TANK) {
            health = 120 + wave * 7;
            speed = 0.75 + wave * 0.015;
            color = new Color(210, 80, 255);
        } else {
            health = 50 + wave * 4;
            speed = 1.25 + wave * 0.02;
            color = new Color(255, 80, 100);
        }
    }

    @Override
    public void update() {
        double dx = player.getX() - x;
        double dy = player.getY() - y;
        double distance = Math.sqrt(dx * dx + dy * dy);
        if (distance > 1) {
            x += dx / distance * speed;
            y += dy / distance * speed;
        }
    }

    @Override
    public void draw(Graphics2D g) {
        g.setColor(color);
        g.fillRect((int)x, (int)y, width, height);
    }

    public void hit(int damage) { health -= damage; }
    public boolean isDead() { return health <= 0; }
    public Type getType() { return type; }
}
