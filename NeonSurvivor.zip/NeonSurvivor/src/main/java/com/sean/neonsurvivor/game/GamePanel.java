package com.sean.neonsurvivor.game;

import com.sean.neonsurvivor.entities.*;
import com.sean.neonsurvivor.ui.Upgrade;

import javax.swing.JPanel;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.*;

public class GamePanel extends JPanel implements KeyListener, MouseListener, MouseMotionListener {
    public static final int WIDTH = 900;
    public static final int HEIGHT = 600;

    private final Random random = new Random();
    private final ArrayList<Enemy> enemies = new ArrayList<>();
    private final ArrayList<Bullet> bullets = new ArrayList<>();
    private final Upgrade[] upgrades = {
        new Upgrade("Heavy Rounds", "+10 weapon damage", 0),
        new Upgrade("Light Feet", "+movement speed", 1),
        new Upgrade("Reinforced", "+20 maximum health", 2),
        new Upgrade("Quick Trigger", "shoot faster", 3)
    };

    private Player player;
    private GameState state = GameState.MENU;
    private int wave = 1;
    private int enemiesToSpawn = 8;
    private int spawnedThisWave = 0;
    private int spawnTimer = 0;
    private int score = 0;
    private int xp = 0;
    private int level = 1;
    private int xpNeeded = 50;
    private int highScore;
    private int mouseX = WIDTH / 2;
    private int mouseY = HEIGHT / 2;
    private boolean shooting;
    private boolean up, down, left, right;

    public GamePanel() {
        setPreferredSize(new Dimension(WIDTH, HEIGHT));
        setBackground(new Color(14, 15, 22));
        setFocusable(true);
        addKeyListener(this);
        addMouseListener(this);
        addMouseMotionListener(this);
        highScore = loadHighScore();
    }

    public void start() {
        new Thread(() -> {
            while (true) {
                long start = System.nanoTime();
                updateGame();
                repaint();
                long elapsed = System.nanoTime() - start;
                long sleep = 16 - elapsed / 1_000_000;
                if (sleep > 0) {
                    try { Thread.sleep(sleep); } catch (InterruptedException ignored) { }
                }
            }
        }).start();
    }

    private void updateGame() {
        if (state != GameState.PLAYING) return;

        player.setMovement(up, down, left, right);
        player.update();
        keepPlayerOnScreen();

        if (shooting && player.canShoot()) shoot();

        updateBullets();
        updateEnemies();
        spawnEnemies();

        if (spawnedThisWave >= enemiesToSpawn && enemies.isEmpty()) {
            wave++;
            enemiesToSpawn = 7 + wave * 3;
            spawnedThisWave = 0;
        }

        if (xp >= xpNeeded) {
            xp -= xpNeeded;
            level++;
            xpNeeded += 25;
            state = GameState.LEVEL_UP;
        }
    }

    private void keepPlayerOnScreen() {
        player.setX(Math.max(0, Math.min(WIDTH - 28, player.getX())));
        player.setY(Math.max(0, Math.min(HEIGHT - 28, player.getY())));
    }

    private void shoot() {
        double tx = mouseX - (player.getX() + 14);
        double ty = mouseY - (player.getY() + 14);
        if (Math.abs(tx) + Math.abs(ty) < 1) return;
        bullets.add(new Bullet(player.getX() + 10, player.getY() + 10, tx, ty, player.getDamage()));
        player.resetShootTimer();
    }

    private void updateBullets() {
        Iterator<Bullet> iterator = bullets.iterator();
        while (iterator.hasNext()) {
            Bullet bullet = iterator.next();
            bullet.update();
            boolean remove = bullet.getX() < -20 || bullet.getX() > WIDTH + 20 || bullet.getY() < -20 || bullet.getY() > HEIGHT + 20;

            for (Enemy enemy : enemies) {
                if (bullet.getBounds().intersects(enemy.getBounds())) {
                    enemy.hit(bullet.getDamage());
                    remove = true;
                    if (enemy.isDead()) {
                        score += enemy.getType() == Enemy.Type.TANK ? 30 : 10;
                        xp += enemy.getType() == Enemy.Type.TANK ? 25 : 10;
                    }
                    break;
                }
            }
            if (remove) iterator.remove();
        }
        enemies.removeIf(Enemy::isDead);
    }

    private void updateEnemies() {
        for (Enemy enemy : enemies) {
            enemy.update();
            if (enemy.getBounds().intersects(player.getBounds())) {
                player.damage(1);
                if (player.getHealth() <= 0) endGame();
            }
        }
    }

    private void spawnEnemies() {
        if (spawnedThisWave >= enemiesToSpawn) return;
        spawnTimer--;
        if (spawnTimer > 0) return;
        spawnTimer = Math.max(12, 45 - wave * 2);

        int side = random.nextInt(4);
        double x = side == 0 ? -30 : side == 1 ? WIDTH + 30 : random.nextInt(WIDTH);
        double y = side == 2 ? -30 : side == 3 ? HEIGHT + 30 : random.nextInt(HEIGHT);

        Enemy.Type type;
        int roll = random.nextInt(100);
        if (wave >= 4 && roll < 12) type = Enemy.Type.TANK;
        else if (wave >= 2 && roll < 35) type = Enemy.Type.FAST;
        else type = Enemy.Type.BASIC;

        enemies.add(new Enemy(x, y, type, player, wave));
        spawnedThisWave++;
    }

    private void startGame() {
        player = new Player(WIDTH / 2.0, HEIGHT / 2.0);
        enemies.clear();
        bullets.clear();
        wave = 1;
        enemiesToSpawn = 8;
        spawnedThisWave = 0;
        spawnTimer = 20;
        score = 0;
        xp = 0;
        level = 1;
        xpNeeded = 50;
        state = GameState.PLAYING;
    }

    private void endGame() {
        if (score > highScore) {
            highScore = score;
            saveHighScore(score);
        }
        state = GameState.GAME_OVER;
    }

    private void chooseUpgrade(int index) {
        if (index < 0 || index >= upgrades.length) return;
        upgrades[index].apply(player);
        state = GameState.PLAYING;
    }

    private Upgrade[] randomUpgrades() {
        ArrayList<Upgrade> list = new ArrayList<>(Arrays.asList(upgrades));
        Collections.shuffle(list, random);
        return new Upgrade[]{list.get(0), list.get(1), list.get(2)};
    }

    private Upgrade[] currentChoices;

    private void drawCentered(Graphics2D g, String text, int y, int size) {
        g.setFont(new Font("Arial", Font.BOLD, size));
        FontMetrics fm = g.getFontMetrics();
        g.drawString(text, (WIDTH - fm.stringWidth(text)) / 2, y);
    }

    @Override protected void paintComponent(Graphics g0) {
        super.paintComponent(g0);
        Graphics2D g = (Graphics2D) g0;
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        if (state == GameState.MENU) drawMenu(g);
        else if (state == GameState.GAME_OVER) drawGameOver(g);
        else {
            drawGame(g);
            if (state == GameState.LEVEL_UP) drawLevelUp(g);
        }
    }

    private void drawMenu(Graphics2D g) {
        g.setColor(new Color(14, 15, 22));
        g.fillRect(0, 0, WIDTH, HEIGHT);
        g.setColor(new Color(70, 220, 255));
        drawCentered(g, "NEON SURVIVOR", 190, 48);
        g.setColor(Color.WHITE);
        drawCentered(g, "A small Java survival game", 235, 18);
        drawCentered(g, "WASD to move  •  Mouse to aim  •  Left click to shoot", 310, 17);
        g.setColor(new Color(70, 220, 255));
        drawCentered(g, "CLICK TO START", 390, 24);
        g.setColor(Color.LIGHT_GRAY);
        drawCentered(g, "High score: " + highScore, 450, 16);
    }

    private void drawGame(Graphics2D g) {
        g.setColor(new Color(14, 15, 22));
        g.fillRect(0, 0, WIDTH, HEIGHT);

        g.setColor(new Color(22, 24, 34));
        for (int x = 0; x < WIDTH; x += 40) g.drawLine(x, 0, x, HEIGHT);
        for (int y = 0; y < HEIGHT; y += 40) g.drawLine(0, y, WIDTH, y);

        player.draw(g);
        for (Bullet bullet : bullets) bullet.draw(g);
        for (Enemy enemy : enemies) enemy.draw(g);

        g.setColor(Color.WHITE);
        g.setFont(new Font("Arial", Font.PLAIN, 16));
        g.drawString("HP: " + player.getHealth() + "/" + player.getMaxHealth(), 18, 25);
        g.drawString("Level: " + level, 18, 48);
        g.drawString("Wave: " + wave, 18, 71);
        g.drawString("Score: " + score, WIDTH - 130, 25);
        g.drawString("XP: " + xp + "/" + xpNeeded, WIDTH - 130, 48);
    }

    private void drawLevelUp(Graphics2D g) {
        g.setColor(new Color(0, 0, 0, 190));
        g.fillRect(0, 0, WIDTH, HEIGHT);
        g.setColor(Color.WHITE);
        drawCentered(g, "LEVEL UP!", 130, 38);
        drawCentered(g, "Choose an upgrade", 165, 18);

        if (currentChoices == null) currentChoices = randomUpgrades();
        for (int i = 0; i < 3; i++) {
            int x = 110 + i * 235;
            g.setColor(new Color(30, 33, 48));
            g.fillRoundRect(x, 220, 205, 150, 15, 15);
            g.setColor(new Color(70, 220, 255));
            g.drawRoundRect(x, 220, 205, 150, 15, 15);
            g.setColor(Color.WHITE);
            drawText(g, (i + 1) + ". " + currentChoices[i].getName(), x + 15, 265, 17);
            drawText(g, currentChoices[i].getDescription(), x + 15, 305, 14);
        }
        drawCentered(g, "Press 1, 2 or 3", 430, 17);
    }

    private void drawGameOver(Graphics2D g) {
        g.setColor(new Color(14, 15, 22));
        g.fillRect(0, 0, WIDTH, HEIGHT);
        g.setColor(new Color(255, 80, 100));
        drawCentered(g, "GAME OVER", 200, 48);
        g.setColor(Color.WHITE);
        drawCentered(g, "Score: " + score + "    Wave: " + wave, 260, 20);
        drawCentered(g, "High score: " + highScore, 300, 18);
        g.setColor(new Color(70, 220, 255));
        drawCentered(g, "Press R to play again", 370, 22);
        g.setColor(Color.LIGHT_GRAY);
        drawCentered(g, "Press ESC for menu", 410, 16);
    }

    private void drawText(Graphics2D g, String text, int x, int y, int size) {
        g.setFont(new Font("Arial", Font.PLAIN, size));
        g.drawString(text, x, y);
    }

    private int loadHighScore() {
        File file = new File("highscore.txt");
        if (!file.exists()) return 0;
        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            return Integer.parseInt(reader.readLine());
        } catch (Exception e) { return 0; }
    }

    private void saveHighScore(int score) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("highscore.txt"))) {
            writer.write(String.valueOf(score));
        } catch (IOException ignored) { }
    }

    @Override public void keyPressed(KeyEvent e) {
        switch (e.getKeyCode()) {
            case KeyEvent.VK_W -> up = true;
            case KeyEvent.VK_S -> down = true;
            case KeyEvent.VK_A -> left = true;
            case KeyEvent.VK_D -> right = true;
            case KeyEvent.VK_1 -> { if (state == GameState.LEVEL_UP) { chooseUpgrade(0); currentChoices = null; } }
            case KeyEvent.VK_2 -> { if (state == GameState.LEVEL_UP) { chooseUpgrade(1); currentChoices = null; } }
            case KeyEvent.VK_3 -> { if (state == GameState.LEVEL_UP) { chooseUpgrade(2); currentChoices = null; } }
            case KeyEvent.VK_R -> { if (state == GameState.GAME_OVER) startGame(); }
            case KeyEvent.VK_ESCAPE -> { state = GameState.MENU; }
        }
    }

    @Override public void keyReleased(KeyEvent e) {
        switch (e.getKeyCode()) {
            case KeyEvent.VK_W -> up = false;
            case KeyEvent.VK_S -> down = false;
            case KeyEvent.VK_A -> left = false;
            case KeyEvent.VK_D -> right = false;
        }
    }

    @Override public void mousePressed(MouseEvent e) {
        if (state == GameState.MENU) { startGame(); return; }
        if (state == GameState.PLAYING && e.getButton() == MouseEvent.BUTTON1) shooting = true;
    }
    @Override public void mouseReleased(MouseEvent e) { if (e.getButton() == MouseEvent.BUTTON1) shooting = false; }
    @Override public void mouseMoved(MouseEvent e) { mouseX = e.getX(); mouseY = e.getY(); }
    @Override public void mouseDragged(MouseEvent e) { mouseMoved(e); }
    @Override public void keyTyped(KeyEvent e) { }
    @Override public void mouseClicked(MouseEvent e) { }
    @Override public void mouseEntered(MouseEvent e) { }
    @Override public void mouseExited(MouseEvent e) { }
}
