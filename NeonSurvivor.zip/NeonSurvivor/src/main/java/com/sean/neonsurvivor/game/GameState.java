package com.sean.neonsurvivor.game;

public enum GameState {
    MENU, PLAYING, LEVEL_UP, GAME_OVER
}
