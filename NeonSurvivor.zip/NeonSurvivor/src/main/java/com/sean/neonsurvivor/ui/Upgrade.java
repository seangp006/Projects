package com.sean.neonsurvivor.ui;

import com.sean.neonsurvivor.entities.Player;

public class Upgrade {
    private final String name;
    private final String description;
    private final int id;

    public Upgrade(String name, String description, int id) {
        this.name = name;
        this.description = description;
        this.id = id;
    }

    public void apply(Player player) {
        switch (id) {
            case 0 -> player.increaseDamage(10);
            case 1 -> player.increaseSpeed(0.6);
            case 2 -> player.increaseMaxHealth(20);
            case 3 -> player.reduceShootDelay(30);
        }
    }

    public String getName() { return name; }
    public String getDescription() { return description; }
}
