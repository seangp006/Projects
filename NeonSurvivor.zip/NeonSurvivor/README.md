# Neon Survivor

A small 2D top-down survival game made in Java. The aim was to build a complete game while practising object-oriented programming, game loops, collision detection, enemy behaviour, collections and file handling.

## Controls
- **WASD** - move
- **Mouse** - aim
- **Left click** - shoot
- **R** - restart after game over
- **ESC** - return to menu

## Features
- Player movement and shooting
- Three enemy types with different movement and health
- Increasing waves and spawn difficulty
- XP and level system
- Three random upgrades on level up
- Collision detection
- Health and score tracking
- High-score saved locally to `highscore.txt`
- Main menu and game-over screen

## Running
Requires Java 17 or newer.

From the project folder:

```bash
javac -d out $(find src/main/java -name "*.java")
java -cp out com.sean.neonsurvivor.Main
```

The game uses Java Swing/AWT only, so there are no external libraries to install.

## Project structure

```text
src/main/java/com/sean/neonsurvivor/
├── Main.java
├── game/
│   ├── GamePanel.java
│   └── GameState.java
├── entities/
│   ├── Entity.java
│   ├── Player.java
│   ├── Enemy.java
│   └── Bullet.java
└── ui/
    └── Upgrade.java
```

## What I practised
- Object-oriented programming and inheritance
- ArrayList-based game entity management
- A fixed-rate game update loop
- Basic vector maths and collision detection
- Randomised enemy spawning and upgrades
- Reading/writing a local score file
- Separating game state, entities and UI code
