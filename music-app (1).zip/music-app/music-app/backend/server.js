const express = require("express");
const cors    = require("cors");
const path    = require("path");
const db      = require("./db");

const app  = express();
const PORT = process.env.PORT || 5000;

app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, "../frontend")));

db.init().then(() => {
  const artistRoutes = require("./routes/artists");
  const albumRoutes  = require("./routes/albums");
  const songRoutes   = require("./routes/songs");

  app.use("/artists", artistRoutes);
  app.use("/albums",  albumRoutes);
  app.use("/songs",   songRoutes);

  app.get("*", (req, res) => {
    res.sendFile(path.join(__dirname, "../frontend/index.html"));
  });

  app.listen(PORT, () => {
    console.log(`Music Library API running at http://localhost:${PORT}`);
  });
}).catch(err => {
  console.error("Failed to initialise database:", err);
  process.exit(1);
});
