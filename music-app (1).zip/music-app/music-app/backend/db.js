const initSqlJs = require("sql.js");
const fs        = require("fs");
const path      = require("path");

const DB_PATH  = path.join(__dirname, "data", "app.db");
const SQL_PATH = path.join(__dirname, "model.sql");

if (!fs.existsSync(path.join(__dirname, "data"))) {
  fs.mkdirSync(path.join(__dirname, "data"));
}

let _db = null;

async function init() {
  const SQL = await initSqlJs();

  if (fs.existsSync(DB_PATH)) {
    const buf = fs.readFileSync(DB_PATH);
    _db = new SQL.Database(buf);
    console.log("Database loaded from disk.");
  } else {
    _db = new SQL.Database();
    const sql = fs.readFileSync(SQL_PATH, "utf8");
    _db.run(sql);
    persist();
    console.log("Database initialised and seeded from model.sql.");
  }

  _db.run("PRAGMA foreign_keys = ON;");
}

function persist() {
  const data = _db.export();
  fs.writeFileSync(DB_PATH, Buffer.from(data));
}

function run(sql, params) {
  _db.run(sql, params || []);
  persist();
  const res = _db.exec("SELECT last_insert_rowid() as id");
  return { lastInsertRowid: res[0] ? res[0].values[0][0] : null };
}

function all(sql, params) {
  const stmt = _db.prepare(sql);
  stmt.bind(params || []);
  const rows = [];
  while (stmt.step()) rows.push(stmt.getAsObject());
  stmt.free();
  return rows;
}

function get(sql, params) {
  return all(sql, params)[0];
}

module.exports = { init, run, all, get };
