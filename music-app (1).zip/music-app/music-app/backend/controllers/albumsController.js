const db = require("../db");

const JOIN = `
  SELECT al.*, ar.artist_name
  FROM albums al
  JOIN artists ar ON al.artist_id = ar.artist_id
`;

exports.getAll = (req, res) => {
  try {
    res.status(200).json(db.all(JOIN + "ORDER BY al.album_id"));
  } catch (err) { res.status(500).json({ error: err.message }); }
};

exports.getOne = (req, res) => {
  try {
    const album = db.get(JOIN + "WHERE al.album_id = ?", [req.params.id]);
    if (!album) return res.status(404).json({ error: "Album not found" });
    res.status(200).json(album);
  } catch (err) { res.status(500).json({ error: err.message }); }
};

exports.create = (req, res) => {
  try {
    const { album_name, release_year, num_listens, artist_id } = req.body;
    if (!album_name || !release_year || !artist_id)
      return res.status(400).json({ error: "album_name, release_year, and artist_id are required" });
    if (!db.get("SELECT 1 FROM artists WHERE artist_id = ?", [artist_id]))
      return res.status(404).json({ error: "Artist not found" });
    const info = db.run(
      "INSERT INTO albums (album_name, release_year, num_listens, artist_id) VALUES (?, ?, ?, ?)",
      [album_name, release_year, num_listens ?? 0, artist_id]
    );
    res.status(201).json(db.get(JOIN + "WHERE al.album_id = ?", [info.lastInsertRowid]));
  } catch (err) { res.status(500).json({ error: err.message }); }
};

exports.update = (req, res) => {
  try {
    const { album_name, release_year, num_listens, artist_id } = req.body;
    const existing = db.get("SELECT * FROM albums WHERE album_id = ?", [req.params.id]);
    if (!existing) return res.status(404).json({ error: "Album not found" });
    db.run(
      "UPDATE albums SET album_name = ?, release_year = ?, num_listens = ?, artist_id = ? WHERE album_id = ?",
      [album_name ?? existing.album_name, release_year ?? existing.release_year,
       num_listens ?? existing.num_listens, artist_id ?? existing.artist_id, req.params.id]
    );
    res.status(200).json(db.get(JOIN + "WHERE al.album_id = ?", [req.params.id]));
  } catch (err) { res.status(500).json({ error: err.message }); }
};

exports.remove = (req, res) => {
  try {
    const existing = db.get("SELECT * FROM albums WHERE album_id = ?", [req.params.id]);
    if (!existing) return res.status(404).json({ error: "Album not found" });
    db.run("DELETE FROM albums WHERE album_id = ?", [req.params.id]);
    res.status(200).json({ message: "Album deleted", album_id: req.params.id });
  } catch (err) { res.status(500).json({ error: err.message }); }
};
