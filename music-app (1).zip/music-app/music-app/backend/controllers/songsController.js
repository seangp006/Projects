const db = require("../db");

const JOIN = `
  SELECT s.*, al.album_name, ar.artist_name
  FROM songs s
  JOIN albums al ON s.album_id = al.album_id
  JOIN artists ar ON al.artist_id = ar.artist_id
`;

exports.getAll = (req, res) => {
  try {
    res.status(200).json(db.all(JOIN + "ORDER BY s.song_id"));
  } catch (err) { res.status(500).json({ error: err.message }); }
};

exports.getOne = (req, res) => {
  try {
    const song = db.get(JOIN + "WHERE s.song_id = ?", [req.params.id]);
    if (!song) return res.status(404).json({ error: "Song not found" });
    res.status(200).json(song);
  } catch (err) { res.status(500).json({ error: err.message }); }
};

exports.create = (req, res) => {
  try {
    const { song_name, release_year, album_id } = req.body;
    if (!song_name || !release_year || !album_id)
      return res.status(400).json({ error: "song_name, release_year, and album_id are required" });
    if (!db.get("SELECT 1 FROM albums WHERE album_id = ?", [album_id]))
      return res.status(404).json({ error: "Album not found" });
    const info = db.run(
      "INSERT INTO songs (song_name, release_year, album_id) VALUES (?, ?, ?)",
      [song_name, release_year, album_id]
    );
    res.status(201).json(db.get(JOIN + "WHERE s.song_id = ?", [info.lastInsertRowid]));
  } catch (err) { res.status(500).json({ error: err.message }); }
};

exports.update = (req, res) => {
  try {
    const { song_name, release_year, album_id } = req.body;
    const existing = db.get("SELECT * FROM songs WHERE song_id = ?", [req.params.id]);
    if (!existing) return res.status(404).json({ error: "Song not found" });
    db.run(
      "UPDATE songs SET song_name = ?, release_year = ?, album_id = ? WHERE song_id = ?",
      [song_name ?? existing.song_name, release_year ?? existing.release_year,
       album_id ?? existing.album_id, req.params.id]
    );
    res.status(200).json(db.get(JOIN + "WHERE s.song_id = ?", [req.params.id]));
  } catch (err) { res.status(500).json({ error: err.message }); }
};

exports.remove = (req, res) => {
  try {
    const existing = db.get("SELECT * FROM songs WHERE song_id = ?", [req.params.id]);
    if (!existing) return res.status(404).json({ error: "Song not found" });
    db.run("DELETE FROM songs WHERE song_id = ?", [req.params.id]);
    res.status(200).json({ message: "Song deleted", song_id: req.params.id });
  } catch (err) { res.status(500).json({ error: err.message }); }
};
