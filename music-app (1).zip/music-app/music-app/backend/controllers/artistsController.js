const db = require("../db");

exports.getAll = (req, res) => {
  try {
    const artists = db.all("SELECT * FROM artists ORDER BY artist_id");
    res.status(200).json(artists);
  } catch (err) { res.status(500).json({ error: err.message }); }
};

exports.getOne = (req, res) => {
  try {
    const artist = db.get("SELECT * FROM artists WHERE artist_id = ?", [req.params.id]);
    if (!artist) return res.status(404).json({ error: "Artist not found" });
    res.status(200).json(artist);
  } catch (err) { res.status(500).json({ error: err.message }); }
};

exports.create = (req, res) => {
  try {
    const { artist_name, genre, monthly_listeners } = req.body;
    if (!artist_name || !genre) return res.status(400).json({ error: "artist_name and genre are required" });
    const info = db.run(
      "INSERT INTO artists (artist_name, genre, monthly_listeners) VALUES (?, ?, ?)",
      [artist_name, genre, monthly_listeners ?? 0]
    );
    const created = db.get("SELECT * FROM artists WHERE artist_id = ?", [info.lastInsertRowid]);
    res.status(201).json(created);
  } catch (err) { res.status(500).json({ error: err.message }); }
};

exports.update = (req, res) => {
  try {
    const { artist_name, genre, monthly_listeners } = req.body;
    const existing = db.get("SELECT * FROM artists WHERE artist_id = ?", [req.params.id]);
    if (!existing) return res.status(404).json({ error: "Artist not found" });
    db.run(
      "UPDATE artists SET artist_name = ?, genre = ?, monthly_listeners = ? WHERE artist_id = ?",
      [artist_name ?? existing.artist_name, genre ?? existing.genre,
       monthly_listeners ?? existing.monthly_listeners, req.params.id]
    );
    res.status(200).json(db.get("SELECT * FROM artists WHERE artist_id = ?", [req.params.id]));
  } catch (err) { res.status(500).json({ error: err.message }); }
};

exports.remove = (req, res) => {
  try {
    const existing = db.get("SELECT * FROM artists WHERE artist_id = ?", [req.params.id]);
    if (!existing) return res.status(404).json({ error: "Artist not found" });
    db.run("DELETE FROM artists WHERE artist_id = ?", [req.params.id]);
    res.status(200).json({ message: "Artist deleted", artist_id: req.params.id });
  } catch (err) { res.status(500).json({ error: err.message }); }
};
