PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS artists (
  artist_id   INTEGER PRIMARY KEY AUTOINCREMENT,
  artist_name TEXT    NOT NULL,
  genre       TEXT    NOT NULL,
  monthly_listeners INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS albums (
  album_id    INTEGER PRIMARY KEY AUTOINCREMENT,
  album_name  TEXT    NOT NULL,
  release_year INTEGER NOT NULL,
  num_listens  INTEGER NOT NULL DEFAULT 0,
  artist_id   INTEGER NOT NULL,
  FOREIGN KEY (artist_id) REFERENCES artists(artist_id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS songs (
  song_id      INTEGER PRIMARY KEY AUTOINCREMENT,
  song_name    TEXT    NOT NULL,
  release_year INTEGER NOT NULL,
  album_id     INTEGER NOT NULL,
  FOREIGN KEY (album_id) REFERENCES albums(album_id) ON DELETE CASCADE
);

INSERT INTO artists (artist_name, genre, monthly_listeners) VALUES
  ('Calvin Harris', 'EDM/Dance',     52000000),
  ('Josh Baker',    'Melodic House',  3000000),
  ('Omar+',         'Tech House',     2500000);

INSERT INTO albums (album_name, release_year, num_listens, artist_id) VALUES
  ('Motion',                  2014, 1200000000, 1),
  ('Funk Wav Bounces Vol. 1', 2017, 900000000,  1),
  ('Funk Wav Bounces Vol. 2', 2022, 600000000,  1),
  ('Watercolour',             2021, 15000000,   2),
  ('Dusk Till Dawn',          2023, 8000000,    2),
  ('Panorama',                2022, 10000000,   3),
  ('Night Shift',             2023, 7000000,    3);

INSERT INTO songs (song_name, release_year, album_id) VALUES
  ('Summer',                2014, 1),
  ('Outside',               2014, 1),
  ('How Deep Is Your Love', 2015, 1),
  ('Slide',                 2017, 2),
  ('Feels',                 2017, 2),
  ('Miracle',               2022, 3),
  ('Potion',                2022, 3),
  ('Watercolour',           2021, 4),
  ('Falling Into Place',    2021, 4),
  ('Dusk Till Dawn',        2023, 5),
  ('Panorama',              2022, 6),
  ('Drift',                 2022, 6),
  ('Night Shift',           2023, 7),
  ('Solitude',              2023, 7);