let timeLeft = 60;
let timer = null;
let isPaused = false;

const timerDisplay = document.getElementById("timer");
const startBtn = document.getElementById("startBtn");
const pauseBtn = document.getElementById("pauseBtn");
const stopBtn = document.getElementById("stopBtn");

/* Update Timer Display */
function updateDisplay() {
    timerDisplay.textContent = timeLeft;

    if (timeLeft <= 15) {
        timerDisplay.style.color = "red";
        timerDisplay.style.backgroundColor = "black";
        timerDisplay.style.padding = "5px";
        timerDisplay.style.borderRadius = "5px";
    }
}

/* Start Timer */
startBtn.onclick = function () {
    timer = setInterval(() => {
        if (!isPaused) {
            timeLeft--;
            updateDisplay();

            if (timeLeft <= 0) {
                clearInterval(timer);
                alert("Time's up! Take a break.");
            }
        }
    }, 1000);

    startBtn.disabled = true;
    pauseBtn.disabled = false;
    stopBtn.disabled = false;
};

/* Pause / Resume */
pauseBtn.onclick = function () {
    isPaused = !isPaused;

    if (isPaused) {
        pauseBtn.textContent = "Resume";
    } else {
        pauseBtn.textContent = "Pause";
    }
};

/* Stop Timer */
stopBtn.onclick = function () {
    clearInterval(timer);
    timeLeft = 60;
    isPaused = false;
    updateDisplay();

    pauseBtn.textContent = "Pause";

    startBtn.disabled = false;
    pauseBtn.disabled = true;
    stopBtn.disabled = true;
};

/* Initial Display */
updateDisplay();
